 // $(window).scroll(function() {
             // if ($(this).scrollTop() >= 500) {        
                 // $('.topUp').fadeIn(200);   
             // } else {
                 // $('.topUp').fadeOut(200);   
             // }
         // });
         // $('.topUp').click(function() {      
             // $('body,html').animate({
                 // scrollTop : 0               
             // }, 500);
         // });