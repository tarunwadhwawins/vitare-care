<div class="sidebar">
    <div class="menuList">
        <ul>
            <li><a href="dashboard" data-bs-toggle="tooltip" data-bs-placement="right" title="Dashboard"><span>Dashboard</span> <i class="fa fa-home" aria-hidden="true"></i></a></li>
            <li><a href="messages" data-bs-toggle="tooltip" data-bs-placement="right" title="Manage Messages"><span>Manage Messages </span> <i class="fa fa-envelope" aria-hidden="true"></i></a></li>
            <li><a href="manage-care-coordinator" data-bs-toggle="tooltip" data-bs-placement="right" title="Manage Care Coordinator"><span>Manage Care Coordinator </span> <i class="fa fa-users" aria-hidden="true"></i></a></li>
            <li><a href="manage-patients" data-bs-toggle="tooltip" data-bs-placement="right" title="Manage Patients"><span>Manage Patients</span> <i class="fa fa-bed" aria-hidden="true"></i></a></li>
            <li><a href="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Assign Care Coordinator"><span>Assign Care Coordinator</span> <i class="fa fa-bed" aria-hidden="true"></i></a></li>
            <li><a href="appoinment-calendar" data-bs-toggle="tooltip" data-bs-placement="right" title="Appointment Calendar"><span>Appointment Calendar</span> <i class="fa fa-calendar" aria-hidden="true"></i></a></li>
        </ul>
    </div>
</div>